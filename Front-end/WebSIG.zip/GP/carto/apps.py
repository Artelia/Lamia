from django.apps import AppConfig


class CartoConfig(AppConfig):
    name = 'carto'
