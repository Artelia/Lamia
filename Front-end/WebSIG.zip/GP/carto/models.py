
from __future__ import unicode_literals
import datetime
from django.contrib import admin
from django.db import models
from django.utils import timezone
from django.core.files import File
from django.forms import ModelForm
from django.contrib.auth.models import User
import datetime




class Siartelia(models.Model):
    id_siartelia = models.AutoField(primary_key=True)

    def __str__(self):
        return str(self.id_siartelia)

    class Meta:
        db_table = 'siartelia'

admin.site.register(Siartelia)




class Projet(models.Model):
    id_projet = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=255)
    datatype = models.CharField(max_length=255)
    version = models.DecimalField(max_digits=999, decimal_places=500)
    dateversion = models.DateField()
    referantartelia = models.CharField(max_length=255, blank=True, null=True)
    contactartelia = models.CharField(max_length=255, blank=True, null=True)
    client = models.CharField(max_length=255, blank=True, null=True)
    localisation = models.CharField(max_length=255, blank=True, null=True)
    contactclient = models.CharField(max_length=255, blank=True, null=True)
    datecreation = models.DateField(default=datetime.datetime.now, blank=True)
    nomdb = models.CharField(max_length=255)

    def __str__(self):
        return self.nom

    class Meta:
        db_table = 'projet'

admin.site.register(Projet)


class Utilisateur(models.Model):
    id_utilisateur = models.AutoField(primary_key=True)
    id_user = models.ForeignKey(User, db_column='id')
    lk_projet = models.ForeignKey(Projet, db_column='lk_projet')

    def __str__(self):
        return self.id_user.username

    class Meta:
        db_table = 'utilisateur'

admin.site.register(Utilisateur)



class Basedonnees(models.Model):
    pk_basedonnees = models.IntegerField(blank=True, null=True)
    metier = models.CharField(max_length=255, blank=True, null=True)
    repertoireressources = models.CharField(max_length=255, blank=True, null=True)
    crs = models.IntegerField(blank=True, null=True)
    version = models.CharField(max_length=255, blank=True, null=True)
    workversion = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'basedonnees_django'


class Revision(models.Model):
    pk_revision = models.AutoField(primary_key=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    datetimeversion = models.DateField(default=datetime.datetime.now, blank=True)

    def __str__(self):
        return str(self.pk_revision)

    class Meta:
        db_table = 'revision'

admin.site.register(Revision)



class Objet(models.Model):
    pk_objet = models.AutoField(primary_key=True)
    id_objet = models.IntegerField(blank=True, null=True, unique=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'objet_django'


    def __str__(self):
        return str(self.id_objet)

class Bdd(models.Model):
    id_bdd = models.AutoField(primary_key=True)
    id_objet = models.ForeignKey(Objet, to_field='id_objet', db_column='id_objet')
    id_ressource = models.ForeignKey('Ressource', to_field='id_ressource', db_column='id_ressource')
    bdd = models.FileField()

    def __str__(self):
        return str(self.id_bdd)

    class Meta:
        db_table = 'bdd'

admin.site.register(Bdd)







class Marche(models.Model):
    pk_marche = models.AutoField(primary_key=True)
    id_marche = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    datemarche = models.DateField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'marche_django'

    def __str__(self):
        return self.libelle

admin.site.register(Marche)



class Ressource(models.Model):
    pk_ressource = models.AutoField(primary_key=True)
    id_ressource = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ressource_django'


    def __str__(self):
        return str(self.id_ressource)





class Descriptionsystem(models.Model):
    pk_descriptionsystem = models.AutoField(primary_key=True)
    id_descriptionsystem = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'descriptionsystem_django'




class Layer(models.Model):
    id_layer = models.AutoField(primary_key=True, db_column='id_layer')
    id_objet = models.ForeignKey(Objet, db_column='id_objet')
    name = models.CharField(max_length=200, blank=True, null=True)
    ref = models.CharField(max_length=200, blank=True, null=True)
    store = models.CharField(max_length=255, blank=True, null=True)
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'carto_layer_django'

    def __str__(self):
        return self.name

admin.site.register(Layer)




class Desordre(models.Model):
    pk_desordre = models.AutoField(primary_key=True)
    id_desordre = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    groupedesordre = models.CharField(max_length=255, blank=True, null=True)
    impact = models.CharField(max_length=255, blank=True, null=True)
    priorite = models.CharField(max_length=255, blank=True, null=True)
    risques = models.CharField(max_length=255, blank=True, null=True)
    lid_descriptionsystem = models.ForeignKey(Descriptionsystem, to_field='id_descriptionsystem', db_column='lid_descriptionsystem')
    cote = models.CharField(max_length=255, blank=True, null=True)
    position = models.CharField(max_length=255, blank=True, null=True)
    catdes = models.CharField(max_length=255, blank=True, null=True)
    typedes = models.CharField(max_length=255, blank=True, null=True)
    geometry = models.BinaryField(db_column='geom')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'desordre_django'

    def __str__(self):
        return self.libelle



class Environnement(models.Model):
    pk_environnement = models.AutoField(primary_key=True)
    id_environnement = models.IntegerField(blank=True, null=True)
    lpk_descriptionsystem = models.ForeignKey(Descriptionsystem, db_column='lpk_descriptionsystem')
    lid_descriptionsystem = models.IntegerField(blank=True, null=True)
    geometry = models.BinaryField(db_column='geom')
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateField(blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'environnement_django'

    def __str__(self):
        return self.libelle

admin.site.register(Environnement)




class Equipement(models.Model):
    pk_equipement = models.AutoField(primary_key=True)
    id_equipement = models.IntegerField(blank=True, null=True)
    lpk_descriptionsystem = models.ForeignKey(Descriptionsystem, db_column='lpk_descriptionsystem')
    categorie = models.CharField(max_length=255, blank=True, null=True)
    lid_ressource1 = models.ForeignKey(Ressource, to_field='id_ressource', db_column='lid_ressource1')
    lid_descriptionsystem = models.IntegerField(blank=True, null=True)
    typeequipement = models.CharField(max_length=255, blank=True, null=True)
    implantation = models.CharField(max_length=255, blank=True, null=True)
    ecoulement = models.CharField(max_length=255, blank=True, null=True)
    utilisation = models.CharField(max_length=255, blank=True, null=True)
    dimverti = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dimhori = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    securite = models.CharField(max_length=255, blank=True, null=True)
    cote = models.CharField(max_length=255, blank=True, null=True)
    position = models.CharField(max_length=255, blank=True, null=True)
    geometry = models.BinaryField(db_column='geom')
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateField(blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'equipement_django'

    def __str__(self):
        return self.libelle

admin.site.register(Equipement)


class Etudestrategie(models.Model):
    pk_etudestrategie = models.AutoField(primary_key=True)
    id_etudestrategie = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    investissements = models.CharField(max_length=255, blank=True, null=True)
    chronologie = models.CharField(max_length=255, blank=True, null=True)
    note = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'etudestrategie_django'

    def __str__(self):
        return self.libelle


class Evenement(models.Model):
    pk_evenement = models.AutoField(primary_key=True)
    id_evenement = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    description = models.CharField(max_length=255, blank=True, null=True)
    gravite = models.IntegerField(blank=True, null=True)
    ref = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'evenement_django'

    def __str__(self):
        return self.libelle

admin.site.register(Evenement)




class Graphique(models.Model):
    pk_graphique = models.AutoField(primary_key=True)
    id_graphique = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    typegraphique = models.CharField(max_length=255, blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'graphique_django'


class Graphiquedata(models.Model):
    pk_graphiquedata = models.AutoField(primary_key=True)
    id_graphiquedata = models.IntegerField(blank=True, null=True)
    lpk_graphique = models.ForeignKey(Graphique, db_column='lpk_graphique')
    typedata = models.CharField(max_length=255, blank=True, null=True)
    x = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    y = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    z = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    index1 = models.CharField(max_length=255, blank=True, null=True)
    index2 = models.CharField(max_length=255, blank=True, null=True)
    index3 = models.CharField(max_length=255, blank=True, null=True)
    index4 = models.CharField(max_length=255, blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    typegraphique = models.CharField(max_length=255, blank=True, null=True)
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'graphiquedata_django'


class Infralineaire(models.Model):
    pk_infralineaire = models.AutoField(primary_key=True)
    id_infralineaire = models.IntegerField(blank=True, null=True)
    lpk_descriptionsystem = models.ForeignKey(Descriptionsystem, db_column='lpk_descriptionsystem')
    lid_descriptionsystem_1 = models.ForeignKey(Descriptionsystem, to_field='id_descriptionsystem',related_name='+', db_column='lid_descriptionsystem_1')
    lid_descriptionsystem_2 = models.ForeignKey(Descriptionsystem, to_field='id_descriptionsystem',related_name='+', db_column='lid_descriptionsystem_2')
    description1 = models.CharField(max_length=255, blank=True, null=True)
    description2 = models.CharField(max_length=255, blank=True, null=True)
    classement = models.CharField(max_length=255, blank=True, null=True)
    aubaredelargeur = models.CharField(max_length=255, blank=True, null=True)
    aubaredevegherbacee = models.CharField(max_length=255, blank=True, null=True)
    aubaredevegarbustive = models.CharField(max_length=255, blank=True, null=True)
    aubaredevegarboree = models.CharField(max_length=255, blank=True, null=True)
    aubaredecommentaire = models.CharField(max_length=255, blank=True, null=True)
    lid_ressource_1 = models.ForeignKey(Ressource, to_field='id_ressource',related_name='+', db_column='lid_ressource_1')
    lid_ressource_2 = models.ForeignKey(Ressource, to_field='id_ressource',related_name='+', db_column='lid_ressource_2')
    lid_ressource_3 = models.ForeignKey(Ressource, to_field='id_ressource',related_name='+', db_column='lid_ressource_3')
    lid_ressource_4 = models.ForeignKey(Ressource, to_field='id_ressource',related_name='+', db_column='lid_ressource_4')
    geometry = models.BinaryField(db_column='geom')
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateField(blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'infralineaire_django'

    def __str__(self):
        return self.libelle

admin.site.register(Infralineaire)





class Intervenant(models.Model):
    pk_intervenant = models.AutoField(primary_key=True)
    id_intervenant = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    nom = models.CharField(max_length=255, blank=True, null=True)
    societe = models.CharField(max_length=255, blank=True, null=True)
    adresse = models.CharField(max_length=255, blank=True, null=True)
    fax = models.CharField(max_length=255, blank=True, null=True)
    tel = models.CharField(max_length=255, blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'intervenant_django'

    def __str__(self):
        return self.libelle


class Interventiontiers(models.Model):
    pk_interventiontiers = models.AutoField(primary_key=True)
    id_interventiontiers = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    urgence = models.CharField(max_length=255, blank=True, null=True)
    estimationcouts = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    estimationduree = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dateestimationecheance = models.DateField(blank=True, null=True)
    phase = models.CharField(max_length=255, blank=True, null=True)
    datedebut = models.DateField(blank=True, null=True)
    datefin = models.DateField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interventiontiers_django'

    def __str__(self):
        return self.libelle



class Messagetiers(models.Model):
    id_messagetiers = models.AutoField(primary_key=True)
    pub_date = models.DateTimeField(blank=True, null=True)
    objet = models.CharField(max_length=200, blank=True, null=True)
    sender = models.CharField(max_length=75, blank=True, null=True)
    text = models.TextField(blank=True, null=True)
    destinataire = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)
    lu = models.NullBooleanField()
    datetimecreation = models.DateTimeField(blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'messagetiers_django'

    def __str__(self):
        return self.objet
    @classmethod
    def create(cls, sender, destinataire, text, objet, nomDB):
        newObjet=Objet()
        newObjet.save(using=nomDB)
        newMessage = cls(sender=sender, destinataire=destinataire, text=text, objet=objet, lu=False,id_objet=newObjet, pub_date=datetime.datetime.now())
        return newMessage

admin.site.register(Messagetiers)



class Modele(models.Model):
    pk_modele = models.AutoField(primary_key=True)
    id_modele = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    logiciel = models.CharField(max_length=255, blank=True, null=True)
    scenario = models.CharField(max_length=255, blank=True, null=True)
    conclusions = models.CharField(max_length=255, blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'modele_django'


    def __str__(self):
        return self.libelle

admin.site.register(Modele)


class Noeud(models.Model):
    pk_noeud = models.AutoField(primary_key=True)
    id_noeud = models.IntegerField(blank=True, null=True)
    lpk_descriptionsystem = models.ForeignKey(Descriptionsystem, db_column='lpk_descriptionsystem')
    geometry = models.BinaryField(db_column='geom')
    id_descriptionsystem = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateField(blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'noeud_django'

    def __str__(self):
        return self.libelle

admin.site.register(Noeud)




class Observation(models.Model):
    pk_observation = models.AutoField(primary_key=True)
    id_observation = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    datetimeobservation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    nombre = models.IntegerField(blank=True, null=True)
    gravite = models.CharField(max_length=255, blank=True, null=True)
    evolution = models.CharField(max_length=255, blank=True, null=True)
    typesuite = models.CharField(max_length=255, blank=True, null=True)
    precisionsuite = models.CharField(max_length=255, blank=True, null=True)
    commentairesuite = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    lid_desordre = models.ForeignKey(Desordre, to_field='id_desordre', db_column='lid_desordre')
    oh_etatvantellerie = models.CharField(max_length=255, blank=True, null=True)
    oh_etatvantelleriecom = models.CharField(max_length=255, blank=True, null=True)
    oh_etatgeniecivil = models.CharField(max_length=255, blank=True, null=True)
    oh_etatgeniecivilcom = models.CharField(max_length=255, blank=True, null=True)
    oh_testmanoeuvre = models.CharField(max_length=255, blank=True, null=True)
    oh_testmanoeuvrecom = models.CharField(max_length=255, blank=True, null=True)
    oh_etancheite = models.IntegerField(blank=True, null=True)
    oh_etancheitecom = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'observation_django'

    def __str__(self):
        return self.libelle

admin.site.register(Observation)




class Photo(models.Model):
    pk_photo = models.AutoField(primary_key=True)
    id_photo = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    numphoto = models.IntegerField(blank=True, null=True)
    typephoto = models.CharField(max_length=255, blank=True, null=True)
    geometry = models.BinaryField(db_column='geom')
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'photo_django'

    def __str__(self):
        return self.libelle

admin.site.register(Photo)



class Topographie(models.Model):
    pk_topographie = models.AutoField(primary_key=True)
    id_topographie = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'topographie_django'

    def __str__(self):
        return self.libelle

admin.site.register(Topographie)

class Pointtopo(models.Model):
    pk_pointtopo = models.AutoField(primary_key=True)
    id_pointtopo = models.IntegerField(blank=True, null=True)
    lpk_topographie = models.ForeignKey(Topographie, db_column='lpk_topographie')
    typepointtopo = models.CharField(max_length=255, blank=True, null=True)
    x = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    y = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    zgps = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    zwgs84 = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    raf09 = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    zmngf = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    precision = models.CharField(max_length=255, blank=True, null=True)
    dx = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    hauteurperche = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    geom = models.TextField(blank=True, null=True)  # This field type is a guess.
    id_topographie = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pointtopo_django'



class Profil(models.Model):
    pk_profil = models.AutoField(primary_key=True)
    id_profil = models.IntegerField(blank=True, null=True)
    lpk_descriptionsystem = models.ForeignKey(Descriptionsystem, db_column='lpk_descriptionsystem')
    date = models.DateField(blank=True, null=True)
    type = models.CharField(max_length=255, blank=True, null=True)
    geom = models.TextField(blank=True, null=True)  # This field type is a guess.
    id_descriptionsystem = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    importancestrat = models.CharField(max_length=255, blank=True, null=True)
    etatfonct = models.CharField(max_length=255, blank=True, null=True)
    qualitegeolocxy = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    qualitegeolocz = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dategeoloc = models.DateField(blank=True, null=True)
    sourcegeoloc = models.CharField(max_length=255, blank=True, null=True)
    parametres = models.CharField(max_length=255, blank=True, null=True)
    listeparametres = models.CharField(max_length=255, blank=True, null=True)
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'profil_django'



class Rapport(models.Model):
    pk_rapport = models.AutoField(primary_key=True)
    id_rapport = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    geometry = models.BinaryField(db_column='geom')
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rapport_django'

    def __str__(self):
        return self.libelle



admin.site.register(Rapport)

class FileForm(ModelForm):
    class Meta:
        model = Rapport
        fields=['libelle', 'file']



class Rasters(models.Model):
    pk_rasters = models.AutoField(primary_key=True)
    id_rasters = models.IntegerField(blank=True, null=True)
    lpk_ressource = models.ForeignKey(Ressource, db_column='lpk_ressource')
    typeraster = models.CharField(max_length=255, blank=True, null=True)
    id_ressource = models.IntegerField(blank=True, null=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    source = models.CharField(max_length=255, blank=True, null=True)
    datetimeressource = models.DateTimeField(blank=True, null=True)
    contactadresse = models.CharField(max_length=255, blank=True, null=True)
    contactnom = models.CharField(max_length=255, blank=True, null=True)
    contactmail = models.CharField(max_length=255, blank=True, null=True)
    contacttel1 = models.CharField(max_length=255, blank=True, null=True)
    contacttel2 = models.CharField(max_length=255, blank=True, null=True)
    file = models.FileField()
    description = models.CharField(max_length=255, blank=True, null=True)
    lid_marche = models.ForeignKey(Marche, to_field='id_marche', db_column='lid_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rasters_django'

    def __str__(self):
        return self.libelle

admin.site.register(Rasters)





class Travaux(models.Model):
    pk_travaux = models.AutoField(primary_key=True, db_column='pk_travaux')
    id_travaux = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    urgence = models.CharField(max_length=255, blank=True, null=True)
    estimationcouts = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    estimationduree = models.DecimalField(max_digits=65535, decimal_places=65535, blank=True, null=True)
    dateestimationecheance = models.DateField(blank=True, null=True)
    phase = models.CharField(max_length=255, blank=True, null=True)
    datedebut = models.DateField(blank=True, null=True)
    datefin = models.DateField(blank=True, null=True)
    lid_observation = models.ForeignKey(Observation, to_field='id_observation', db_column='lid_observation')
    lk_marche = models.ForeignKey(Marche, db_column='lk_marche')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'travaux_django'


    def __str__(self):
        return self.libelle


class Zonegeo(models.Model):
    pk_zonegeo = models.AutoField(primary_key=True)
    id_zonegeo = models.IntegerField(blank=True, null=True, unique=True)
    lpk_objet = models.ForeignKey(Objet, db_column='lpk_objet')
    pays = models.CharField(max_length=255, blank=True, null=True)
    region = models.CharField(max_length=255, blank=True, null=True)
    commune = models.CharField(max_length=255, blank=True, null=True)
    populations = models.CharField(max_length=255, blank=True, null=True)
    contextesocioeco = models.CharField(max_length=255, blank=True, null=True)
    importancesociale = models.IntegerField(blank=True, null=True)
    importanceindustrielle = models.IntegerField(blank=True, null=True)
    typezonegeo = models.CharField(max_length=255, blank=True, null=True)
    geometry = models.BinaryField(db_column='geom')
    id_objet = models.IntegerField(blank=True, null=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    datetimecreation = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimemodification = models.DateTimeField(default=datetime.datetime.now, blank=True, null=True)
    datetimedestruction = models.DateTimeField(blank=True, null=True)
    commentaire = models.CharField(max_length=255, blank=True, null=True)
    libelle = models.CharField(max_length=255, blank=True, null=True)
    importid = models.IntegerField(blank=True, null=True)
    importtable = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'zonegeo_django'

    def __str__(self):
        return self.libelle





admin.site.register(Desordre)






class Tcetudetravaux(models.Model):
    pk_tcetudetravaux = models.AutoField(primary_key=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    lid_etudestrategie = models.ForeignKey(Etudestrategie, to_field='id_etudestrategie', db_column='lid_etudestrategie')
    lid_travaux = models.ForeignKey(Travaux, to_field='id_travaux', db_column='lid_travaux')

    class Meta:
        managed = False
        db_table = 'tcetudetravaux_django'


class TcetudetravauxInline(admin.TabularInline):
    model = Tcetudetravaux

class EtudeAdmin(admin.ModelAdmin):
    inlines=(TcetudetravauxInline,)


admin.site.register(Etudestrategie, EtudeAdmin)


class TravauxAdmin(admin.ModelAdmin):
    inlines=(TcetudetravauxInline,)

admin.site.register(Travaux, TravauxAdmin)
admin.site.register(Descriptionsystem)






class Tcobjetintervenant(models.Model):
    pk_tcobjetintervenant = models.AutoField(primary_key=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    lid_intervenant = models.ForeignKey(Intervenant, to_field='id_intervenant', db_column='lid_intervenant')
    lid_objet = models.ForeignKey(Objet, to_field='id_objet', db_column='lid_objet')
    fonction = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tcobjetintervenant_django'






class TcobjetintervenantInline(admin.TabularInline):
    model = Tcobjetintervenant



class IntervenantAdmin(admin.ModelAdmin):
    inlines=(TcobjetintervenantInline,)

admin.site.register(Intervenant, IntervenantAdmin)







class Tcobjetressource(models.Model):
    pk_tcobjetressource = models.AutoField(primary_key=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    lid_ressource = models.ForeignKey(Ressource, to_field='id_ressource', db_column='lid_ressource')
    lid_objet = models.ForeignKey(Objet, to_field='id_objet', db_column='lid_objet')

    class Meta:
        managed = False
        db_table = 'tcobjetressource_django'




class TcobjetressourceInline(admin.TabularInline):
    model = Tcobjetressource

class RessourceAdmin(admin.ModelAdmin):
    inlines=(TcobjetressourceInline,)

admin.site.register(Ressource, RessourceAdmin)






class Tcobjetzonegeo(models.Model):
    pk_tcobjetzonegeo = models.AutoField(primary_key=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    lid_zonegeo = models.ForeignKey(Zonegeo, to_field='id_zonegeo', db_column='lid_zonegeo')
    lid_objet = models.ForeignKey(Objet, to_field='id_objet', db_column='lid_objet')

    class Meta:
        managed = False
        db_table = 'tcobjetzonegeo_django'






class TcobjetzonegeoInline(admin.TabularInline):
    model = Tcobjetzonegeo

class ObjetAdmin(admin.ModelAdmin):
    inlines=(TcobjetintervenantInline,TcobjetressourceInline,TcobjetzonegeoInline)

class ZonegeoAdmin(admin.ModelAdmin):
    inlines=(TcobjetzonegeoInline,)

admin.site.register(Zonegeo, ZonegeoAdmin)
admin.site.register(Objet, ObjetAdmin)







### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IL VA FALOIR GERER CE CAS
class Tctravauxdescriptionsystem(models.Model):
    pk_tctravauxdescriptionsystem = models.AutoField(primary_key=True)
    lpk_revision_begin = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_begin')
    lpk_revision_end = models.ForeignKey(Revision,related_name='+', db_column='lpk_revision_end')
    lid_travaux = models.ForeignKey(Travaux, to_field='id_travaux', db_column='lid_travaux')
    lid_descriptionsystem = models.ForeignKey(Descriptionsystem, to_field='id_descriptionsystem', db_column='lid_descriptionsystem')

    class Meta:
        managed = False
        db_table = 'tctravauxdescriptionsystem_django'