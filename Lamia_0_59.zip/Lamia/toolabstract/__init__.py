"""
MainModule core
"""

from .InspectionDigue_abstract_tool import *