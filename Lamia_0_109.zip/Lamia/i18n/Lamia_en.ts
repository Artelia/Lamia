<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="en" sourcelanguage="fr">
<context>
    <name>Form</name>
    <message>
        <location filename="../toolprepro/base2/lamiabase_zonegeo_tool_ui.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="53"/>
        <source>Elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="129"/>
        <source>Lk</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="154"/>
        <source>Zoomer sur l&apos;objet sélectionné</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="186"/>
        <source>Ajouter automatiquement la dernière photo prise</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="218"/>
        <source>Ajouter un nouvel élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="244"/>
        <source>Supprimer un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="276"/>
        <source>Annuler les modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="302"/>
        <source>Sauvegarder un élément</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="358"/>
        <source>Saisie geometrique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="394"/>
        <source>Saisir un point unique sur la tablette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="432"/>
        <source>Saisir un linéaire (plusieurs points) sur la tablette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="470"/>
        <source>Saisir une surface (plusieurs points) sur la tablette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="508"/>
        <source>Rajouter un point à la géométrie actuelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="546"/>
        <source>Saisir un point GPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="586"/>
        <source>Attributs</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_propertieswidget.ui" line="690"/>
        <source>Propriétés</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_croquis_tool_ui.ui" line="29"/>
        <source>Editer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_croquis_tool_ui.ui" line="36"/>
        <source>Ouvrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="29"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="42"/>
        <source>Valeurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="339"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="332"/>
        <source>dZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="311"/>
        <source>dY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="100"/>
        <source>Z NGF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="297"/>
        <source>dX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="114"/>
        <source>Z wgs84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="283"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="148"/>
        <source>Z gps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="248"/>
        <source>RAF09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="367"/>
        <source>Haut. perche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="208"/>
        <source>Acquerir les valeurs GPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="228"/>
        <source>GPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="374"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="255"/>
        <source>Zgps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="269"/>
        <source>Zwgs84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_pointtopo_tool_ui.ui" line="304"/>
        <source>Z mNGF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_raster_tool_ui.ui" line="45"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_raster_tool_ui.ui" line="52"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fichier&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_raster_tool_ui.ui" line="68"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_zonegeo_tool_ui.ui" line="42"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_raster_tool_ui.ui" line="85"/>
        <source>Charger</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../toolprepro/base2/lamiabase_raster_tool_ui.ui" line="102"/>
        <source>Libellé</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_zonegeo_tool_ui.ui" line="32"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolprepro/base2/lamiabase_zonegeo_tool_ui.ui" line="55"/>
        <source>Statistiques</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InspectiondigueWindowWidget</name>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget.py" line="174"/>
        <source>Prestation inactif</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget.py" line="177"/>
        <source>GPS non connect&#xc3;&#xa9;</source>
        <translation>GPS not connected</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget.py" line="179"/>
        <source>Pr&#xc3;&#xa9;cision</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="208"/>
        <source>Sélectionner la date à laquelle afficher le système</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="214"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="291"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="505"/>
        <source>Proprietes</source>
        <translation>Properties</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="525"/>
        <source>Tables enfants</source>
        <translation>Chlidrens tables</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="615"/>
        <source>Fichiers</source>
        <translation>Files</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="619"/>
        <source>Bases recentes</source>
        <translation>Recents databases</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="625"/>
        <source>Charger base</source>
        <translation>Load database</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="632"/>
        <source>Import / export</source>
        <translation>Imort/export</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="647"/>
        <source>Préférences</source>
        <translation>Settings</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="660"/>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="669"/>
        <source>Aide</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="682"/>
        <source>tre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="687"/>
        <source>temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="710"/>
        <source>Répertoire photo</source>
        <translation>Photos directory</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="700"/>
        <source>Digue</source>
        <translation>Levee</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="705"/>
        <source>Assainissement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="718"/>
        <source>Utilisateur</source>
        <translation>User</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="726"/>
        <source>Terrain</source>
        <translation>Field investigation</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="734"/>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="742"/>
        <source>Bureau</source>
        <translation>Office</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="747"/>
        <source>postgis</source>
        <translation>postgis</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="752"/>
        <source>spatialite</source>
        <translation>spatialite</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="757"/>
        <source>Nouvelle base</source>
        <translation>New database</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="762"/>
        <source>Reinitialier prestation courante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="767"/>
        <source>Se connecter au GPS</source>
        <translation>GPS connection</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="772"/>
        <source>Aide </source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="780"/>
        <source>A propos</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="785"/>
        <source>Taille icones</source>
        <translation>Icons size</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="790"/>
        <source>Hauteur de perche GPS</source>
        <translation>GPS perch height</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="798"/>
        <source>Post traitement</source>
        <translation>Post processing</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="803"/>
        <source>Infralineaires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="808"/>
        <source>Imprimer rapport</source>
        <translation>Report printing</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="813"/>
        <source>Réinitialiser les noeuds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="818"/>
        <source>Export shapefile</source>
        <translation>Shapefile export</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="823"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="828"/>
        <source>Mode hors ligne/Reconnexion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="833"/>
        <source>version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="838"/>
        <source>Importer depuis SIRS Digues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="843"/>
        <source>Exporter vers SIRS Digues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="848"/>
        <source>Exporter pour l&apos;inspection terrain</source>
        <translation>Export for field investigation</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="853"/>
        <source>Importer et ajouter une base de données</source>
        <translation>Import and append database</translation>
    </message>
    <message>
        <location filename="../dialog/InspectionDigue_windowwidget_base.ui" line="858"/>
        <source>Importer l&apos;inspection terrain</source>
        <translation>Import field investigation</translation>
    </message>
</context>
</TS>
