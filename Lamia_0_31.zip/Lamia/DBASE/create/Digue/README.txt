Contraintes:
champ avec date : "Date"****
Idparent : "Id"+nomtableparet
Id liaison : "Lk"+nomtableliaison