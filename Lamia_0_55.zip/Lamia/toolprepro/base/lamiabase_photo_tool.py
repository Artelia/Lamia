# -*- coding: utf-8 -*-

from qgis.PyQt import uic, QtCore, QtGui
try:
    from qgis.PyQt.QtGui import (QWidget, QLabel, QFrame)
except ImportError:
    from qgis.PyQt.QtWidgets import (QWidget, QLabel, QFrame)
from ...toolabstract.InspectionDigue_abstract_tool import AbstractInspectionDigueTool
import os
import datetime
import glob
from .lamiabase_photoviewer import PhotoViewer

prefixhoto = ''
numphoto = None


class BasePhotoTool(AbstractInspectionDigueTool):

    LOADFIRST = False
    dbasetablename = 'Photo'

    def __init__(self, dbase, dialog=None, linkedtreewidget=None,gpsutil=None, parentwidget=None, parent=None):
        super(BasePhotoTool, self).__init__(dbase, dialog, linkedtreewidget,gpsutil, parentwidget, parent=parent)

    def initTool(self):
        # ****************************************************************************************
        # Main spec
        self.CAT = 'Ressources'
        self.NAME = 'Photographies'
        self.dbasetablename = 'Photo'
        self.visualmode = [ 1, 2]
        self.PointENABLED = True
        # self.LineENABLED = True
        # self.PolygonEnabled = True
        self.magicfunctionENABLED = True
        self.linkagespec = {'Tcobjetressource' : {'tabletc' : 'Tcobjetressource',
                                              'idsource' : 'id_ressource',
                                            'idtcsource' : 'id_tcressource',
                                           'iddest' : 'id_objet',
                                           'idtcdest' : 'id_tcobjet',
                                           'desttable' : ['Infralineaire','Observation','Equipement','Noeud','Profil']} }
        # self.pickTable = None
        self.iconpath = os.path.join(os.path.dirname(__file__), 'lamiabase_photo_tool_icon.svg')

        # ****************************************************************************************
        #properties ui


        # ****************************************************************************************
        # userui
    def initFieldUI(self):
        if self.userwdgfield is None:
            self.userwdgfield = UserUI()
            self.linkuserwdgfield = {'Photo' : {'linkfield' : 'id_photo',
                                             'widgets' : {}},
                                'Objet' : {'linkfield' : 'id_objet',
                                          'widgets' : {}},
                                'Ressource' : {'linkfield' : 'id_ressource',
                                          'widgets' : {'file': self.userwdgfield.lineEdit_file,
                                                       'numphoto': self.userwdgfield.spinBox_numphoto,
                                                        'dateressource' : self.userwdgfield.dateEdit}}}

            self.userwdgfield.stackedWidget.setCurrentIndex(0)
            self.userwdgfield.pushButton_chooseph.clicked.connect(self.choosePhoto)
            self.userwdgfield.pushButton_lastph.clicked.connect(self.lastPhoto)
            self.userwdgfield.pushButton_openph.clicked.connect(self.openPhoto)
            self.photowdg = PhotoViewer()
            self.userwdgfield.frame_ph.layout().addWidget(self.photowdg)

            self.userwdgfield.toolButton_photoplus.clicked.connect(self.changeNumPhoto)
            self.userwdgfield.toolButton_photomoins.clicked.connect(self.changeNumPhoto)
            self.userwdgfield.toolButton_calc.clicked.connect(
                lambda: self.windowdialog.showNumPad(self.userwdgfield.spinBox_numphoto))


            if False:
                # ****************************************************************************************
                # parent widgets
                if self.parentWidget is not None and 'lk_photo' in self.dbase.dbasetables[self.parentWidget.dbasetablename]['fields'].keys():
                    self.userwdgfield.pushButton_defaultphoto.clicked.connect(self.setDefaultPhoto)
                else:
                    self.userwdgfield.pushButton_defaultphoto.setParent(None)


            # ****************************************************************************************
            # child widgets
            pass


    def changeNumPhoto(self):

        global prefixhoto
        global numphoto

        if numphoto is None:
            numphoto = 0

        if self.sender() == self.userwdgfield.toolButton_photoplus:
            numphoto += 1
        elif self.sender() == self.userwdgfield.toolButton_photomoins:
            numphoto = numphoto -1
        self.userwdgfield.spinBox_numphoto.setValue(numphoto)





    def postOnActivation(self):
        pass

    def postOnDesactivation(self):
        pass

    def postloadIds(self,sqlin):
        sqlin += " AND typephoto = 'PHO'"
        return sqlin

    def magicFunction(self):
        self.featureSelected()
        self.lastPhoto()
        self.addGPSPoint()
        self.saveFeature()

    def setDefaultPhoto(self):
        # print('setDefaultPhoto', self.currentparentfeature)
        if self.parentWidget.currentFeature is not None:
            idphoto = self.currentFeature['id_objet']
            idparentfeature=self.parentWidget.currentFeature['id_objet']
            # print('setDefaultPhoto',idphoto,idparentfeature)
            sql = "UPDATE " + str(self.parentWidget.dbasetablename) + " SET  lk_photo = " + str(idphoto) + " WHERE id_objet = " + str(idparentfeature) + ";"
            query = self.dbase.query(sql)
            self.dbase.commit()


    def choosePhoto(self):
        file, extension = self.windowdialog.qfiledlg.getOpenFileNameAndFilter(None, 'Choose the file', self.dbase.imagedirectory,
                                                                 'Image (*.jpg)', '')
        if file:
            self.userwdg.lineEdit_file.setText(os.path.normpath(file))
            self.showImageinLabelWidget(self.photowdg , self.userwdg.lineEdit_file.text())


    def lastPhoto(self):
        if self.dbase.imagedirectory is not None:
            list_of_files = glob.glob(self.dbase.imagedirectory + "//*.jpg")
            try :
                latest_file = max(list_of_files, key=os.path.getctime)
                self.userwdg.lineEdit_file.setText(os.path.normpath(latest_file))
                self.showImageinLabelWidget(self.photowdg , self.userwdg.lineEdit_file.text())
            except ValueError:
                pass

    def openPhoto(self):
        filepath = self.dbase.completePathOfFile(self.userwdg.lineEdit_file.text())
        if os.path.isfile(filepath ):
            os.startfile(filepath)


    def postInitFeatureProperties(self, feat):

        global prefixhoto
        global numphoto


        if self.currentFeature is None:
            datecreation = QtCore.QDate.fromString(str(datetime.date.today()), 'yyyy-MM-dd').toString('yyyy-MM-dd')
            self.initFeatureProperties(feat, 'Ressource', 'dateressource', datecreation)

            if numphoto is not None:
                self.userwdgfield.spinBox_numphoto.setValue(numphoto)

            # geom if parent is node
            if self.parentWidget is not None and self.parentWidget.currentFeature is not None:
                if self.parentWidget.dbasetablename == 'Noeud':

                    # get geom
                    noeudfet = self.dbase.getLayerFeatureByPk('Noeud', self.parentWidget.currentFeature.id())
                    neudfetgeom = noeudfet.geometry().asPoint()
                    self.createorresetRubberband(1)
                    self.setTempGeometry([neudfetgeom], False,False)

        """
        if self.parentWidget is not None and self.parentWidget.currentFeature is not None:
            if self.parentWidget.dbasetablename == 'TRONCON':
                self.initFeatureProperties(feat, 'LkObjet', self.parentWidget.currentFeature.id())
            elif self.parentWidget.dbasetablename == 'OBSERVATION':
                self.initFeatureProperties(feat, 'LkObjet', self.parentWidget.currentFeature.id())
        """

        if feat is not None:
            sql = "SELECT file FROM Ressource  WHERE id_ressource = " + str(feat['id_ressource']) + ";"
            query = self.dbase.query(sql)
            result = [row[0] for row in query]
            #print('post',result)
            file = result[0]
            if file is not None and file != '':
                self.showImageinLabelWidget(self.photowdg, self.userwdg.lineEdit_file.text())
            else:
                self.photowdg.clear()
        else:
            self.photowdg.clear()

    def createParentFeature(self):

        lastrevision = self.dbase.maxrevision
        datecreation = QtCore.QDate.fromString(str(datetime.date.today()), 'yyyy-MM-dd').toString('yyyy-MM-dd')
        lastobjetid = self.dbase.getLastId('Objet') + 1
        sql = "INSERT INTO Objet (id_objet, id_revisionbegin, datecreation ) "
        sql += "VALUES(" + str(lastobjetid ) + "," + str(lastrevision) +  ",'" + datecreation + "');"
        query = self.dbase.query(sql)
        self.dbase.commit()
        #idobjet = self.dbase.getLastRowId('Objet')


        lastressourceid = self.dbase.getLastId('Ressource') + 1
        sql = "INSERT INTO Ressource (id_ressource, id_revisionbegin, id_objet) "
        sql += "VALUES(" + str(lastressourceid) + "," + str(lastrevision) +  "," + str(lastobjetid) + ");"
        query = self.dbase.query(sql)
        self.dbase.commit()


        idphoto = self.currentFeature.id()
        lastidphoto = self.dbase.getLastId('Photo') + 1




        sql = "UPDATE Photo SET id_objet = " + str(lastobjetid)  + ","
        sql += "id_ressource = " + str(lastressourceid)   + ","
        sql += "id_photo = " + str(lastidphoto)  + ","
        sql += "id_revisionbegin = " + str(lastrevision) + ","
        sql += "typephoto = 'PHO' "
        sql += " WHERE pk_photo = " + str(idphoto) + ";"
        query = self.dbase.query(sql)
        self.dbase.commit()

        if self.parentWidget is not None and self.parentWidget.currentFeature is not None:
            currentparentlinkfield = self.parentWidget.currentFeature['id_objet']
            sql = "INSERT INTO Tcobjetressource(id_tcobjet, id_tcressource,id_revisionbegin) "
            sql += " VALUES(" + str(currentparentlinkfield) + ", " + str(lastressourceid) + "," + str(lastrevision) + ");"
            query = self.dbase.query(sql)
            self.dbase.commit()




    def postSaveFeature(self, boolnewfeature):
        global prefixhoto
        global numphoto

        #if numphoto is not None:
        if self.userwdgfield.spinBox_numphoto.value() == -1 :
            numphoto = None
        elif numphoto == self.userwdgfield.spinBox_numphoto.value():
            numphoto += 1
        else:
            numphoto = self.userwdgfield.spinBox_numphoto.value() + 1

        print('postSaveFeature', numphoto)


    def deleteParentFeature(self):
        idobjet = self.currentFeature['id_objet']
        idressource = self.currentFeature['id_ressource']

        sql = "DELETE FROM Objet WHERE id_objet = " + str(idobjet) + ";"
        query = self.dbase.query(sql)
        self.dbase.commit()

        sql = "DELETE FROM Ressource WHERE id_objet = " + str(idobjet) + ";"
        query = self.dbase.query(sql)
        self.dbase.commit()

        sql = "DELETE FROM Tcobjetressource WHERE id_tcressource = " + str(idressource) + ";"
        query = self.dbase.query(sql)
        self.dbase.commit()

        return True

class UserUI(QWidget):
    def __init__(self, parent=None):
        super(UserUI, self).__init__(parent=parent)
        uipath = os.path.join(os.path.dirname(__file__), 'lamiabase_photo_tool_ui.ui')
        uic.loadUi(uipath, self)

