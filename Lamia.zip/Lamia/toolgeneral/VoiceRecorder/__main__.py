from main.Ui.MainWindow import MainWindow

if __name__ == '__main__':
    MainWindow.run()