<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr" sourcelanguage="en">
<context>
    <name>AbstractLamiaFormTool</name>
    <message>
        <location filename="../iface/qgiswidget/tools/lamia_abstractformtool.py" line="556"/>
        <source>GPS not connected</source>
        <translation>GPS non connecté</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/lamia_abstractformtool.py" line="629"/>
        <source>Delete feature (yes) or archive (no) ? </source>
        <translation>Supprimer completement l&apos;element (yes) ou l&apos;archiver (no) ?</translation>
    </message>
</context>
<context>
    <name>DBaseOfflineManager</name>
    <message>
        <location filename="../dbasemanager/dbaseofflinemanager.py" line="79"/>
        <source>Il y a dÃ©jÃ&#xa0; une copie locale de la base... Supprimez la</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form_base3</name>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="58"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="60"/>
        <source>Adress</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="67"/>
        <source>Society</source>
        <translation>Société</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="77"/>
        <source>Fax</source>
        <translation>Fax</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="87"/>
        <source>Mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="94"/>
        <source>Phone</source>
        <translation>Téléphone</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="51"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;File&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="71"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="170"/>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="187"/>
        <source>picture number</source>
        <translation>Numero photo</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="194"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="331"/>
        <source>Controller view</source>
        <translation>Vue de l&apos;armoire elec.</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="403"/>
        <source>Coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="410"/>
        <source>Editer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="417"/>
        <source>Ouvrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_deficiency_tool_ui.ui" line="73"/>
        <source>A remplir avec les spec desordre cat1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_deficiency_tool_ui.ui" line="84"/>
        <source>A remplir avec les spec desordre cat2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool_ui.ui" line="104"/>
        <source>Properties</source>
        <translation>Propriétés</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="191"/>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_equipment_tool_ui.ui" line="56"/>
        <source>Equimment category</source>
        <translation>Catégorie</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_equipment_tool_ui.ui" line="73"/>
        <source>cat1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_equipment_tool_ui.ui" line="84"/>
        <source>cat2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_raster_tool_ui.ui" line="84"/>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_geoarea_tool_ui.ui" line="64"/>
        <source>Statistics</source>
        <translation>Statistiques</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="63"/>
        <source>Graph type</source>
        <translation>Type de graphique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="390"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="271"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="160"/>
        <source>Index1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="165"/>
        <source>Index2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="170"/>
        <source>Index3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="175"/>
        <source>Index4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="53"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_node_tool_ui.ui" line="20"/>
        <source>GroupBox</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="48"/>
        <source>Urgency</source>
        <translation>Urgence</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="82"/>
        <source>Number</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="150"/>
        <source>NOD</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="174"/>
        <source>Equip</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="198"/>
        <source>Next action type</source>
        <translation>Type de suite</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_report_tool_ui.ui" line="71"/>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_report_tool_ui.ui" line="94"/>
        <source>dd/MM/yyyy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="145"/>
        <source>Acquisition</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="161"/>
        <source>Add point from GPS</source>
        <translation>Ajouter un point du GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="171"/>
        <source>Import</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="180"/>
        <source>Importer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="243"/>
        <source>GPS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="397"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="299"/>
        <source>RAF09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="306"/>
        <source>dZ</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="313"/>
        <source>dX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="320"/>
        <source>dY</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="334"/>
        <source>Zgps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="341"/>
        <source>Z mNGF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="322"/>
        <source>Haut. perche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="376"/>
        <source>Zwgs84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="29"/>
        <source>Point type</source>
        <translation>Type de point</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="42"/>
        <source>Values</source>
        <translation>Valeurs</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="48"/>
        <source>Z wgs84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="119"/>
        <source>Z gps</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="159"/>
        <source>Z NGF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool_ui.ui" line="101"/>
        <source>Role</source>
        <translation>Fonction</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="78"/>
        <source>Open camera app</source>
        <translation>Ouvrir l&apos;appareil photo</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="232"/>
        <source>Show</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_camera_tool_ui.ui" line="239"/>
        <source>Last picture</source>
        <translation>Dernière photo</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="271"/>
        <source>Define as default picture</source>
        <translation>Définir comme photo principale</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="310"/>
        <source>Global view</source>
        <translation>Vue générale</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_camera_tool_ui.ui" line="317"/>
        <source>trap view</source>
        <translation>Vue de la cuve</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="324"/>
        <source>Float view</source>
        <translation>Vue des poires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="338"/>
        <source>Valve view</source>
        <translation>Vue des vannes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_deficiency_tool_ui.ui" line="56"/>
        <source>Deficiency car</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool_ui.ui" line="91"/>
        <source>Delivery ref</source>
        <translation>Référence du marché</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool_ui.ui" line="110"/>
        <source>Define as current delivery</source>
        <translation>Définir comme le marché courant</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool_ui.ui" line="120"/>
        <source>Actors</source>
        <translation>Intervenants</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool_ui.ui" line="148"/>
        <source>Define actors</source>
        <translation>Définir les acteurs</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="87"/>
        <source>Plot</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool_ui.ui" line="105"/>
        <source>Datas</source>
        <translation>Données</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="239"/>
        <source>Last take</source>
        <translation>Dernière prise</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_media_tool_ui.ui" line="317"/>
        <source>Trap view</source>
        <translation>Vue de la cuve</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="75"/>
        <source>Progression</source>
        <translation>Evolution</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool_ui.ui" line="185"/>
        <source>Next action</source>
        <translation>Suite à donner</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_report_tool_ui.ui" line="128"/>
        <source>Load</source>
        <translation>Charger</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool_ui.ui" line="135"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="362"/>
        <source>Rod height</source>
        <translation>Hauteur de la perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool_ui.ui" line="223"/>
        <source>Get GPS data</source>
        <translation>Charger les données GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_sketch_tool_ui.ui" line="29"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_facility_tool_ui.ui" line="81"/>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_facility_tool_ui.ui" line="64"/>
        <source>Operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_facility_tool_ui.ui" line="101"/>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form_base3_ud</name>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_camera_tool_defaultbuttons_ui.ui" line="48"/>
        <source>Controller view</source>
        <translation>Vue de l&apos;armoire elec.</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_deficiency_tool_ui.ui" line="97"/>
        <source>Fill with cat1 widget - If empty go to observations</source>
        <translation>A remplir avec la widget cat1 - Si vide aller dans Observation</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_deficiency_tool_ui.ui" line="108"/>
        <source>Fill with cat2 widget - If empty go to observations</source>
        <translation>A remplir avec la widget cat2 - Si vide aller dans Observation</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="587"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="75"/>
        <source>Node</source>
        <translation>Noeud</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="193"/>
        <source>material</source>
        <translation>Materiau</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="335"/>
        <source>Nominal diameter / width</source>
        <translation>Diamètre nominal/largeur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="222"/>
        <source>Function</source>
        <translation>Fonction</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="47"/>
        <source>Domain</source>
        <translation>Domaine</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_equipment_tool_ui_CD41.ui" line="56"/>
        <source>Category</source>
        <translation>Categorie</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_equipment_tool_ui_CD41.ui" line="76"/>
        <source>Equipment type</source>
        <translation>Type d&apos;équipement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_equipment_tool_ui_CD41.ui" line="127"/>
        <source>cat2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="63"/>
        <source>Network type</source>
        <translation>Type de reseau</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="83"/>
        <source>Node type</source>
        <translation>Type de noeud</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="116"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="146"/>
        <source>Handle presence</source>
        <translation>Présence de crosse</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="213"/>
        <source>Steps presence</source>
        <translation>Présence d&apos;échelons</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="217"/>
        <source>Remote monitoring comments</source>
        <translation>Telegestion commentaires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="197"/>
        <source>Material</source>
        <translation>Materiau</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="831"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="950"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="880"/>
        <source>dY</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="873"/>
        <source>dX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="866"/>
        <source>dZ</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="803"/>
        <source>GPS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="957"/>
        <source>/</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="859"/>
        <source>RAF09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="894"/>
        <source>Zgps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="901"/>
        <source>Z mNGF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="936"/>
        <source>Zwgs84</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="96"/>
        <source>Node subtype</source>
        <translation>Sous-type de noeud</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="243"/>
        <source>Accessibility</source>
        <translation>Accessibilité</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="327"/>
        <source>H2S treatment</source>
        <translation>Traitement de l&apos;H2S</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="364"/>
        <source>Nominal capacity (m3/h)</source>
        <translation>Capacité nominale (m3/h)</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="384"/>
        <source>Overflow</source>
        <translation>Surverse</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="468"/>
        <source>Geometry</source>
        <translation>Géométrie</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="560"/>
        <source>Lenght - diameter</source>
        <translation>Longueur - diamètre</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="741"/>
        <source>GPS - tampon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="41"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="51"/>
        <source>Urgency</source>
        <translation>Urgence</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="153"/>
        <source>Number</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="289"/>
        <source>Maintenance opinion</source>
        <translation>Avis sur l&apos;entretien</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="217"/>
        <source>Infiltrations</source>
        <translation>Infiltrations</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="221"/>
        <source>Culvert condition</source>
        <translation>Etat du radier</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="250"/>
        <source>H2S suspicion</source>
        <translation>Suspicion d&apos;H2S</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_2018SNCF.ui" line="318"/>
        <source>Equip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_camera_tool_defaultbuttons_ui.ui" line="20"/>
        <source>Global view</source>
        <translation>Vue générale</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_camera_tool_defaultbuttons_ui.ui" line="27"/>
        <source>Trap view</source>
        <translation>Vue de la cuve</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_camera_tool_defaultbuttons_ui.ui" line="34"/>
        <source>Float view</source>
        <translation>Vue des poires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_camera_tool_defaultbuttons_ui.ui" line="41"/>
        <source>Valve view</source>
        <translation>Vue des vannes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_deficiency_tool_ui.ui" line="77"/>
        <source>Deficiency cat</source>
        <translation>Catégorie du désordre</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="68"/>
        <source>Upstream</source>
        <translation>Amont</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="106"/>
        <source>Downstream</source>
        <translation>Aval</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="530"/>
        <source>Depth</source>
        <translation>Profondeur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="255"/>
        <source>Lateral</source>
        <translation>Branchement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui.ui" line="187"/>
        <source>Creation year</source>
        <translation>Date de pose</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="232"/>
        <source>Flow type</source>
        <translation>Type d&apos;écoulement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui.ui" line="221"/>
        <source>Pipe shape</source>
        <translation>Forme de la canalisation</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="325"/>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="84"/>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="73"/>
        <source>Location</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_edge_tool_ui_CD41.ui" line="281"/>
        <source>Creation date</source>
        <translation>Date de pose</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="144"/>
        <source>Cover shape</source>
        <translation>Type de tampon</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="86"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="160"/>
        <source>Manhole shape</source>
        <translation>Forme du regard</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="196"/>
        <source>Electrical cabinet</source>
        <translation>Armoire éléctrique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="230"/>
        <source>Elec. cab presence</source>
        <translation>Présence d&apos;une armoire éléctrique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="294"/>
        <source>Remote monitoring</source>
        <translation>Télégestion</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="267"/>
        <source>Interior</source>
        <translation>Intérieur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="304"/>
        <source>Pump switching controller type</source>
        <translation>Type de contrôle de la permutation</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="314"/>
        <source>Float</source>
        <translation>Poires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="352"/>
        <source>Pumps</source>
        <translation>Pompes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="365"/>
        <source>Pumps count</source>
        <translation>Nombre de pompes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="380"/>
        <source>Valve chamber</source>
        <translation>Chambre de vannes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="392"/>
        <source>Alarm presence</source>
        <translation>Présence d&apos;une alarme</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="399"/>
        <source>Controller presence</source>
        <translation>Présence d&apos;un automate</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="540"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_2018SNCF.ui" line="499"/>
        <source>Lenght</source>
        <translation>Longueur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="721"/>
        <source>Z cover</source>
        <translation>Z tampon</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="922"/>
        <source>Rod height</source>
        <translation>Hauteur de la perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="84"/>
        <source>Condition</source>
        <translation>Etat</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="143"/>
        <source>Progression</source>
        <translation>Evolution</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="227"/>
        <source>Infiltration to sewer</source>
        <translation>ECPP</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="198"/>
        <source>Cover condition</source>
        <translation>Etat du tampon</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="211"/>
        <source>Steps condition</source>
        <translation>Etat des échelons</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="234"/>
        <source>Manhole condition</source>
        <translation>Etat du regard</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="263"/>
        <source>Sedimentation</source>
        <translation>Dépôts</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="276"/>
        <source>Pressurized flow</source>
        <translation>Mise en charge</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="337"/>
        <source>Roots presence</source>
        <translation>Présence de racines</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_2018SNCF.ui" line="242"/>
        <source>Sum condition</source>
        <translation>Etat de la bâche</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_2018SNCF.ui" line="262"/>
        <source>Floats condition</source>
        <translation>Etat des poires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="71"/>
        <source>General condition</source>
        <translation>Etat général</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_2018SNCF.ui" line="283"/>
        <source>Sedimentation/clutter</source>
        <translation>Ensablement/encombrement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="492"/>
        <source>Follow-up</source>
        <translation>Suite à donner</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="523"/>
        <source>Follow-up type</source>
        <translation>Type de suite</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui.ui" line="549"/>
        <source>Follow-up subtype</source>
        <translation>Sous-type de suite</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_observation_tool_ui_CD41.ui" line="316"/>
        <source>Opened ?</source>
        <translation>Ouvert ?</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="171"/>
        <source>Cover diameter</source>
        <translation>Diamètre du tampon</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="284"/>
        <source>Overflow depth</source>
        <translation>Profondeur de la surverse</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui_CD41.ui" line="354"/>
        <source>Pumps number</source>
        <translation>Nombre de pompes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="24"/>
        <source>Main properties</source>
        <translation>Propriétéd principales</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="128"/>
        <source>Depth </source>
        <translation>Profondeur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="180"/>
        <source>Secondary properties</source>
        <translation>Propriétés secondaires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="193"/>
        <source>Low flow channel presence</source>
        <translation>Présence d&apos;une cunette</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="247"/>
        <source>Siphoid partition</source>
        <translation>Cloison siphoïde</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="254"/>
        <source>Tip</source>
        <translation>Couvercle</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="267"/>
        <source>Lateral user type</source>
        <translation>Usager</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="300"/>
        <source>Exterior</source>
        <translation>Extérieur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="306"/>
        <source>Locked site</source>
        <translation>Site vérouillé</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="316"/>
        <source>Fence presence</source>
        <translation>Présence d&apos;une cloture</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="401"/>
        <source>Elec. cab locked</source>
        <translation>Armoire éléctrique vérouillée</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="411"/>
        <source>Pump switching controller</source>
        <translation>Permutation des pompes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="494"/>
        <source>Fall protection gratings presence</source>
        <translation>Présence d&apos;une grile anti-chute</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="507"/>
        <source>Inlet screen presence</source>
        <translation>Présence d&apos;un panier dégrilleur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="554"/>
        <source>Guide rail presence</source>
        <translation>Présence de rail de guidage</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="564"/>
        <source>Pump lifting chain presence</source>
        <translation>Présence d&apos;une chaîne de levage</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="587"/>
        <source>Check valve presence</source>
        <translation>Présence d&apos;une vanne</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="597"/>
        <source>Gate valve presence </source>
        <translation>Présence d&apos;un clapet anti-retour</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="610"/>
        <source>Pressure port presence</source>
        <translation>PRésence d&apos;une prise de pression</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3_urbandrainage/lamiabase_ud_node_tool_ui.ui" line="665"/>
        <source>Sediment trap</source>
        <translation>Présence d&apos;une fosse de décantation</translation>
    </message>
</context>
<context>
    <name>Form_main</name>
    <message>
        <location filename="../iface/qgiswidget/tools/lamia_abstractformtool.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/lamia_abstractformtool.ui" line="97"/>
        <source>Tab 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/lamia_abstractformtool.ui" line="180"/>
        <source>Properties</source>
        <translation>Propriétés</translation>
    </message>
</context>
<context>
    <name>Form_subwidget</name>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/subwidgets/subwidget_signature_ui.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/subwidgets/subwidget_lidchooser_ui.ui" line="23"/>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/subwidgets/subwidget_tcmanytomany_ui.ui" line="41"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/subwidgets/subwidget_tcmanytomany_ui.ui" line="48"/>
        <source>Remove</source>
        <translation>Retirer</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/subwidgets/subwidget_signature_ui.ui" line="86"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
</context>
<context>
    <name>Lamia</name>
    <message>
        <location filename="../Lamia.py" line="191"/>
        <source>&amp;Lamia</source>
        <translation>Lamia</translation>
    </message>
    <message>
        <location filename="../Lamia.py" line="165"/>
        <source>Lamia</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LamiaWindowWidget</name>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="859"/>
        <source>GPS not connected</source>
        <translation>GPS non connecté</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="133"/>
        <source>GPS rod height : /</source>
        <translation>Hauteur de la perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="135"/>
        <source>Accuracy</source>
        <translation>Précision</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="233"/>
        <source>Lamia new</source>
        <translation>Lamia nouveau</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="215"/>
        <source>Select resources directory</source>
        <translation>Selectionner le répertoire des resources</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="259"/>
        <source> Database creation...</source>
        <translation>Création de la base de données</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="301"/>
        <source>Loading Layers ...</source>
        <translation>Chargement des couches</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="382"/>
        <source>Choose the file</source>
        <translation>Choisir le fichier</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="775"/>
        <source>Loading widgets...</source>
        <translation>Chargement des extensions</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="850"/>
        <source>GPS connected</source>
        <translation>GPS connecté</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="860"/>
        <source>Rod height : {}</source>
        <translation>Hauteur de la perche GPS : {}</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="854"/>
        <source>Accuracy : error</source>
        <translation>Précision : erreur</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="863"/>
        <source>Accuracy : off</source>
        <translation>Précision : désactivé</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="892"/>
        <source>Rod height</source>
        <translation>Hauteur de la perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="892"/>
        <source>Enter GPS rod height</source>
        <translation>Renseigner la hauteur de perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.py" line="902"/>
        <source>Select Directory</source>
        <translation>Choisir le répertoire</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_sketch_tool_drawingwidg_ui.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="208"/>
        <source>SÃ©lectionner la date Ã&#xa0; laquelle afficher le systÃ¨me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="214"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="291"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="505"/>
        <source>Proprietes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="525"/>
        <source>Tables enfants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="619"/>
        <source>Recent DB</source>
        <translation>DB récentes</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="632"/>
        <source>Import / export</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="660"/>
        <source>Interface</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="714"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="728"/>
        <source>tre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="733"/>
        <source>temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="738"/>
        <source>RÃ©pertoire photo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="746"/>
        <source>Digue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="751"/>
        <source>Assainissement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="764"/>
        <source>Utilisateur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="780"/>
        <source>Expert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="793"/>
        <source>postgis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="798"/>
        <source>spatialite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="808"/>
        <source>Reinitialier prestation courante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="813"/>
        <source>Connect to Qgis GPS</source>
        <translation>Se connecter au GPS QGis</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="818"/>
        <source>Aide </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="826"/>
        <source>A propos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="831"/>
        <source>Taille icones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="836"/>
        <source>GPS rod height</source>
        <translation>Hauteur de la perche GPS</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="844"/>
        <source>Post treatment</source>
        <translation>Post traitement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="849"/>
        <source>Infralineaires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="854"/>
        <source>Imprimer rapport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="859"/>
        <source>RÃ©initialiser les noeuds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="864"/>
        <source>Export shapefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="869"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="874"/>
        <source>Mode hors ligne/Reconnexion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="879"/>
        <source>version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="884"/>
        <source>Importer depuis SIRS Digues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="889"/>
        <source>Exporter vers SIRS Digues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="894"/>
        <source>CrÃ©er une copie locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="909"/>
        <source>Tables et champs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="918"/>
        <source>toolbarsave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="927"/>
        <source>toolbarnew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="936"/>
        <source>toobargeomnewpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="945"/>
        <source>toobargeomnewline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="954"/>
        <source>toobargeomanewpolygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="963"/>
        <source>toolbardelete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="972"/>
        <source>toolbarundo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="981"/>
        <source>toobargeomaddpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="990"/>
        <source>toobargeomaddGPSpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="999"/>
        <source>toobargeomeditlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="615"/>
        <source>Files</source>
        <translation>Fichiers</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="625"/>
        <source>Load DB</source>
        <translation>Charger une base de données</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="647"/>
        <source>Settings</source>
        <translation>Préférences</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="669"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="772"/>
        <source>Field investigation</source>
        <translation>Terrain</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="788"/>
        <source>Office</source>
        <translation>Bureau</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="803"/>
        <source>New DB</source>
        <translation type="unfinished">Nouvelle base de données</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="899"/>
        <source>Add a DB to this DB</source>
        <translation>RAjouter une DB à la DB actuelle</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="904"/>
        <source>Push local DB </source>
        <translation>Reverser la base de données sur la base mère</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="756"/>
        <source>Camera directory</source>
        <translation>Répertoire des photos</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="1008"/>
        <source>toolbarlayersave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/ifaceqgswidget.ui" line="1017"/>
        <source>toolbarlayerundo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>base3</name>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_geoarea_tool.py" line="41"/>
        <source>Management</source>
        <translation>Gestion</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_actor_tool.py" line="46"/>
        <source>Actors</source>
        <translation>Intervenants</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool.py" line="42"/>
        <source>Resources</source>
        <translation>Ressources</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_camera_tool.py" line="56"/>
        <source>Camera</source>
        <translation>Photo</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool.py" line="46"/>
        <source>Condition</source>
        <translation>Etat</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_deficiency_tool.py" line="47"/>
        <source>Deficiency</source>
        <translation>Désordre</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_delivery_tool.py" line="48"/>
        <source>Delivery</source>
        <translation>Marché</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_node_tool.py" line="46"/>
        <source>Facilities</source>
        <translation>Infrastructures</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_edge_tool.py" line="47"/>
        <source>Pipes</source>
        <translation>Canalisations</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_equipment_tool.py" line="44"/>
        <source>Equipment</source>
        <translation>Equipement</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_geoarea_tool.py" line="42"/>
        <source>Geographic area</source>
        <translation>Zone géographique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_geoarea_tool.py" line="65"/>
        <source>Linear facilities</source>
        <translation>Infrastructures linéaires</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graph_tool.py" line="58"/>
        <source>Graph</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_graphcsv_tool.py" line="61"/>
        <source>Graph_csv</source>
        <translation>Graphique csv</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_node_tool.py" line="47"/>
        <source>Nodes</source>
        <translation>Noeuds</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_observation_tool.py" line="47"/>
        <source>Observation</source>
        <translation>Observation</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_raster_tool.py" line="46"/>
        <source>Background map</source>
        <translation>Fond de plan</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_report_tool.py" line="43"/>
        <source>Report</source>
        <translation>Rapports</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_sketch_tool.py" line="48"/>
        <source>Sketches</source>
        <translation>Schémas</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool.py" line="48"/>
        <source>Topography</source>
        <translation>Topographie</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topography_tool.py" line="112"/>
        <source>Topographic point</source>
        <translation>Points topo</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_topographydata_tool.py" line="145"/>
        <source>GPS not connected</source>
        <translation>GPS non connecté</translation>
    </message>
    <message>
        <location filename="../iface/qgiswidget/tools/toolprepro/base3/lamiabase_facility_tool.py" line="46"/>
        <source>Facility</source>
        <translation>Aménagement</translation>
    </message>
</context>
</TS>
