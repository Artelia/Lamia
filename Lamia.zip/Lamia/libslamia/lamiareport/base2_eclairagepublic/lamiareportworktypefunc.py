import os
import qgis, qgis.core

