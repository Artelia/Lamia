Plugin Builder Results


pip install --proxy=10.1.3.47:3128 pyserial


Your plugin GPS2Point was created in:
    C:\Users\patrice.verchere\Documents\GitHub\Nouveau dossier\GPS2Point

Your QGIS plugin directory is located at:
    C:/Users/patrice.verchere/.qgis2/python/plugins

What's Next:

  * Copy the entire directory containing your new plugin to the QGIS plugin
    directory

  * Compile the resources file using pyrcc4

  * Run the tests (``make test``)

  * Test the plugin by enabling it in the QGIS plugin manager

  * Customize it by editing the implementation file: ``GPS2Point.py``

  * Create your own custom icon, replacing the default icon.png

  * Modify your user interface by opening GPS2Point.ui in Qt Designer

  * You can use the Makefile to compile your Ui and resource files when
    you make changes. This requires GNU make (gmake)

For more information, see the PyQGIS Developer Cookbook at:
http://www.qgis.org/pyqgis-cookbook/index.html

(C) 2011-2014 GeoApt LLC - geoapt.com
Git revision : $Format:%H$




TOPO
nearest...

base donnnes clean et shema ok
doc abstracttool
profil ....
gps maj ok

fonction import



TODO
3 modifier combobox id (rajout str) ou treewidget
3 gestion obj protection
2 :raster

Recap Desordres
PL


TODO
1 gestion geometrie (desordre + click rajout point) OK...
3 modifier combobox id (rajout str) ou treewidget
2 gestion PT    EN COURS OK...
3 gestion obj protection
2 : gestion avertissement OK...
2 :raster

Recap Desordres
PL


TODO 21/10
1 gestion geometrie (desordre + click rajout point)
3 gestion gps   OK
3 modifier combobox id (rajout str) ou treewidget
2 gestion PT    EN COURS
3 gestion obj protection
2 Faire emprise digue : topo + desordre OK
2 : gestion avertissement


TODO - 19/10/2017
1 gestion geometrie (desordre + click rajout point)
1 gestion rapport (requete spatiale) - unifier librairie requete spatialite OK
1 gestion topo  OK
3 gestion gps
3 modifier combobox id (rajout str) ou treewidget
2 gestion PT    EN COURS
3 gestion obj protection
2 gestion ressources doc OK
2 Faire emprise digue : topo + desordre
