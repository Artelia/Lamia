# -*- coding: utf-8 -*-

import qgis
import os
#from ..toolabstract.inspectiondigue_abstractworker import AbstractWorker
from qgis.PyQt import QtGui, uic, QtCore, QtXml
from collections import OrderedDict
import datetime
import decimal
import logging

from .importtools.InspectionDigue_Import import ImportObjetDialog

try:
    from qgis.PyQt.QtGui import (QInputDialog,QTableWidgetItem,QComboBox,QAction,QProgressBar,QApplication,QWidget)
except ImportError:
    from qgis.PyQt.QtWidgets import (QInputDialog,QTableWidgetItem,QComboBox,QAction,QProgressBar,QApplication,QWidget)


from ...toolabstract.Lamia_abstract_tool import AbstractLamiaTool


class ImportTool(AbstractLamiaTool):
    DBASES = ['digue', 'base_digue', 'base2_digue', 'base2_parking']

    def __init__(self, dbase, dialog=None, linkedtreewidget=None, gpsutil=None, parentwidget=None, parent=None):
        super(ImportTool, self).__init__(dbase, dialog, linkedtreewidget, gpsutil, parentwidget, parent=parent)
        self.postInit()



    def initTool(self):
        # ****************************************************************************************
        # Main spec
        self.CAT = 'Import/export'
        self.NAME = 'Import'
        self.visualmode = [4]
        # self.PointENABLED = True
        # self.LineENABLED = True
        # self.PolygonEnabled = True
        # self.magicfunctionENABLED = True
        # self.linkagespec = None
        # self.pickTable = None
        # print(self.dbase.recentsdbase)

        self.iconpath = os.path.join(os.path.dirname(__file__), 'Lamia_import_tool_icon.png')
        #self.qtreewidgetfields = ['libelle']

        # ****************************************************************************************
        # properties ui
        self.groupBox_geom.setParent(None)
        self.groupBox_elements.setParent(None)



    def postInit(self):
        pass

    def initFieldUI(self):
        if self.userwdgfield is None:

            # ****************************************************************************************
            # userui

            self.userwdgfield = UserUI()
            self.userwdgfield.toolButton_update.clicked.connect(self.updateTable)

            items = ["Points topo", "Infralineaire", 'Noeud', 'Photos']
            self.userwdgfield.comboBox_typeimport.addItems(items)

            self.userwdgfield.pushButton_import.clicked.connect(self.showTable)
            self.userwdgfield.pushButton_importer.clicked.connect(self.work)



    def postOnActivation(self):
        self.updateTable()

    def updateTable(self):

        self.userwdgfield.comboBox_tableimport.clear()

        if self.dbase.qgsiface is not None:
            layers = self.dbase.qgsiface.legendInterface().layers()
            layqgis=[]
            for tablename in self.dbase.dbasetables.keys():
                layqgis.append(self.dbase.dbasetables[tablename]['layerqgis'])

            for lay in layers:
                if not lay in layqgis:
                    self.userwdgfield.comboBox_tableimport.addItems([lay.name()])


    def showTable(self):
        item = self.userwdgfield.comboBox_typeimport.currentText()
        self.currentlayer = None
        if self.dbase.qgsiface is not None:
            # if not self.dbase.standalone:
            for lay in self.dbase.qgsiface.legendInterface().layers():
                if self.userwdgfield.comboBox_tableimport.currentText() == lay.name():
                    self.currentlayer = lay
                    break

            if self.currentlayer  is None:
                return

            currentlayerfields = self.currentlayer .fields()
            currentlayerfieldsname = [''] + [field.name() for field in currentlayerfields]
            # combofield = QComboBox([''] + currentlayerfieldsname)
        else:  # debug outside qgis
            currentlayerfieldsname = ['', 'ALTINGF', 'typ']

        if item == "Points topo":
            print('ok')
            templinkuserwgd = self.dbase.dbasetables['Topographie']['widget'][0].propertieswdgPOINTTOPO.linkuserwdg
        if item == "Infralineaire":
            templinkuserwgd = self.dbase.dbasetables['Infralineaire']['widget'][0].linkuserwdg
        if item == "Desordre":
            templinkuserwgd = self.dbase.dbasetables['Desordre']['widget'][0].linkuserwdg
        if item == "Observation":
            templinkuserwgd = self.dbase.dbasetables['Observation']['widget'][0].linkuserwdg
        if item == "Noeud":
            templinkuserwgd = self.dbase.dbasetables['Noeud']['widget'][0].linkuserwdg
        if item == "Equipement":
            templinkuserwgd = self.dbase.dbasetables['Equipement']['widget'][0].linkuserwdg
        if item == "Travaux":
            templinkuserwgd = self.dbase.dbasetables['Travaux']['widget'][0].linkuserwdg
        if item == "Environnement":
            templinkuserwgd = self.dbase.dbasetables['Environnement']['widget'][0].linkuserwdg
        if item == "Photos":
            templinkuserwgd = self.dbase.dbasetables['Photos']['widget'][0].linkuserwdg

        self.userwdgfield.tableWidget.setRowCount(0)
        self.userwdgfield.tableWidget.setColumnCount(2)
        for tablename in templinkuserwgd:
            if tablename in self.dbase.dbasetables.keys():
                dbasetable = self.dbase.dbasetables[tablename]
                for field in dbasetable['fields'].keys():
                    # print(field)
                    rowPosition = self.userwdgfield.tableWidget.rowCount()
                    self.userwdgfield.tableWidget.insertRow(rowPosition)
                    itemfield = QTableWidgetItem(tablename + '.' + field)
                    itemfield.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
                    self.userwdgfield.tableWidget.setItem(rowPosition, 0, itemfield)
                    # item.setFlags()
                    if field[0:2] != 'id' and field[0:2] != 'pk':
                        combofield = QComboBox()
                        combofield.addItems(currentlayerfieldsname)
                        self.userwdgfield.tableWidget.setCellWidget(rowPosition, 1, combofield)
                    else:
                        itemfield = QTableWidgetItem('')
                        self.userwdgfield.tableWidget.setItem(rowPosition, 1, itemfield)

        #self.importobjetdialog.exec_()
        #tableview = self.importobjetdialog.dialogIsFinished()
        if False:
            if tableview is not None:
                result = []
                for row in range(self.userwdgfield.tableWidget.rowCount()):
                    if self.userwdgfield.tableWidget.cellWidget(row, 1) is not None:
                        result.append([self.userwdgfield.tableWidget.item(row, 0).text(),
                                       self.userwdgfield.tableWidget.cellWidget(row, 1).currentText()])
                    else:
                        result.append([self.userwdgfield.tableWidget.item(row, 0).text(),
                                       self.userwdgfield.tableWidget.item(row, 1).text()])

                self.work(result)



    def work(self,layer=None):
        """

        :param linktable: une liste qui correspond au tableau du dialog :
                         [...[colonne1;colonne2]...]
        :param layer:  pour le debug - possibilite de passer un layer autre
        :return:
        """
        debug = False


        self.results = []
        for row in range(self.userwdgfield.tableWidget.rowCount()):
            if self.userwdgfield.tableWidget.cellWidget(row, 1) is not None:
                self.results.append([self.userwdgfield.tableWidget.item(row, 0).text(),
                               self.userwdgfield.tableWidget.cellWidget(row, 1).currentText()])
            else:
                self.results.append([self.userwdgfield.tableWidget.item(row, 0).text(),
                               self.userwdgfield.tableWidget.item(row, 1).text()])

        if debug: logging.getLogger('Lamia').debug('start %s', str(self.results))



        tablestemp = [result[0].split('.')[0] for result in self.results]

        # print(tables)

        # print(self.results)



        uniquetables = list(set(tablestemp))
        tables = [result[0].split('.')[0] for result in self.results]
        fields = [result[0].split('.')[1] for result in self.results]
        tablefield = [result[0] for result in self.results]
        values = [result[1] for result in self.results]

        if debug: logging.getLogger('Lamia').debug('start %s', str(self.importtable))
        if debug: logging.getLogger('Lamia').debug('tables %s', str(tables))
        if debug: logging.getLogger('Lamia').debug('fields %s', str(fields))

        if layer is None or isinstance(layer, bool):   # come from qqis app
            # layer = self.dbase.qgsiface.activeLayer()
            layer = self.currentlayer
        else:
            layer = layer

            # qgis.core.QgsVectorLayer('C://001_travail_BM//testtopo//toposijalag1.shp', 'test', "ogr")
        progress = self.initProgressBar(len([fet for fet in layer.getFeatures()]))
        layerfromfieldsname = [field.name() for field in layer.fields()]
        #print('layerfromfieldsname',layerfromfieldsname)
        self.xform = qgis.core.QgsCoordinateTransform(layer.crs(), self.dbase.qgiscrs)
        if len(layer.selectedFeatures()) == 0:
            feats  = layer.getFeatures()
        else:
            feats = layer.selectedFeatures()

        if debug: logging.getLogger('Lamia').debug('selected feat %s', [fet.id() for fet in feats])


        # cas des couches enfant de descriptionsystem
        if 'Objet' in tables and 'Descriptionsystem' in uniquetables:
            if debug: logging.getLogger('Lamia').debug('Descriptionsystem')
            for compt, layerfeat in enumerate(layer.getFeatures()):

                if debug: logging.getLogger('Lamia').debug('feat %s', layerfeat.attributes())
                self.setLoadingProgressBar(progress, compt)
                #create objet
                if False:
                    lastrevision = self.dbase.maxrevision
                    datecreation = QtCore.QDate.fromString(str(datetime.date.today()), 'yyyy-MM-dd').toString('yyyy-MM-dd')
                    lastobjetid = self.dbase.getLastId('Objet') + 1
                    sql = "INSERT INTO Objet (id_objet, id_revisionbegin, datecreation ) "
                    sql += "VALUES(" + str(lastobjetid) + "," + str(lastrevision) + ",'" + datecreation + "');"
                    query = self.dbase.query(sql)
                    #self.dbase.commit()
                    pkobjet = self.dbase.getLastRowId('Objet')
                pkobjet = self.dbase.createNewObjet()

                for i, table in enumerate(tables):
                    if table == 'Objet' and values[i] != '':
                        sql = "UPDATE Objet SET " + fields[i] + " = " + str(layerfeat[values[i]])
                        sql += " WHERE pk_objet = " + str(pkobjet)

                        query = self.dbase.query(sql, docommit=False)
                self.dbase.commit()

                lastdescriptionsystemid = self.dbase.getLastId('Descriptionsystem') + 1
                if False:
                    sql = "INSERT INTO Descriptionsystem (id_descriptionsystem, id_revisionbegin, id_objet) "
                    sql += "VALUES(" + str(lastdescriptionsystemid) + "," + str(lastrevision) + "," + str(lastobjetid) + ");"
                sql = "INSERT INTO Descriptionsystem (id_descriptionsystem, lpk_objet) "
                sql += "VALUES(" + str(lastdescriptionsystemid) + "," + str(pkobjet) + ");"

                query = self.dbase.query(sql)
                #self.dbase.commit()
                pkdessys= self.dbase.getLastRowId('Descriptionsystem')

                for i, table in enumerate(tables):
                    if table == 'Descriptionsystem' and values[i] != '':
                        sql = "UPDATE Descriptionsystem SET " + fields[i] + " = " + str(layerfeat[values[i]])
                        sql += " WHERE pk_descriptionsystem = " + str(pkdessys)
                        query = self.dbase.query(sql, docommit=False)
                self.dbase.commit()

                lastsubdescriptionsystemid = self.dbase.getLastId(self.importtable) + 1
                #geom
                featgeom = layerfeat.geometry()
                success = featgeom.transform(self.xform)
                featgeomwkt = featgeom.exportToWkt()
                geomsql = "ST_GeomFromText('"
                geomsql += featgeomwkt
                geomsql += "', " + str(self.dbase.crsnumber) + ")"
                if False:
                    sql = "INSERT INTO " + self.importtable + " (id_objet, id_descriptionsystem, id_revisionbegin, id_" + self.importtable.lower() + ", geom )"
                    sql += " VALUES(" + str(lastobjetid) + "," + str(lastdescriptionsystemid) +',' + str(lastrevision) + "," + str(lastsubdescriptionsystemid) + ","
                    sql += geomsql + ');'


                sql = "INSERT INTO " + self.importtable + " ( lpk_descriptionsystem,  id_" + self.importtable.lower() + ", geom )"
                sql += " VALUES("  + str(pkdessys) +',' + str(lastsubdescriptionsystemid) + ","
                sql += geomsql + ');'
                query = self.dbase.query(sql)
                #self.dbase.commit()
                pksubdessys= self.dbase.getLastRowId(self.importtable)

                for i, table in enumerate(tables):
                    if table == self.importtable and values[i] != '':
                        sql = "UPDATE " + self.importtable + " SET " + fields[i] + " = " + str(layerfeat[values[i]])
                        sql += " WHERE pk_" + self.importtable + " = " + str(pksubdessys)
                        query = self.dbase.query(sql, docommit=False)
                self.dbase.commit()


                self.postImport(layerfeat,pkobjet, pkdessys, pksubdessys )







        if False and self.importtable == 'Points topo':
            table = 'Pointtopo'
            fielddestination=['typepointtopo', 'x', 'y', 'zgps', 'zwgs84', 'raf09', 'zmngf', 'precision', 'dx', 'dy', 'dz', 'hauteurperche',
                    'id_topographie','geom']


            linktable = {}
            for i, result in enumerate(self.results):
                for j, field in enumerate(fielddestination):
                    if table + '.' + field in result:
                        linktable[j] = i

            # print(linktable)




            for layerfeat in feats:
                sql = "INSERT INTO Pointtopo (" + ', '.join(fielddestination) + ") "
                sql += "VALUES("
                featvalues = []
                for i, field in enumerate(fielddestination):
                    # print('values',field,featvalues)
                    if field == 'geom':
                        featgeom = layerfeat.geometry()
                        success = featgeom.transform(self.xform)
                        featgeomwkt = featgeom.exportToWkt()

                        geomsql = "ST_GeomFromText('"
                        geomsql += featgeomwkt
                        geomsql += "', " + str(self.dbase.crsnumber) + ")"
                        featvalues.append(geomsql)
                    else:
                        valuefieldtemp = values[linktable[i]]
                        # print(valuefieldtemp, layerfromfieldsname)
                        if valuefieldtemp == '':
                            featvalues.append('NULL')
                        else:


                            if valuefieldtemp in layerfromfieldsname:
                                valuefieldtemp = layerfeat[valuefieldtemp]
                                # print(valuefieldtemp)
                                if valuefieldtemp is None:
                                    featvalues.append('NULL')
                                else:
                                    # print(type(valuefieldtemp))
                                    if isinstance(valuefieldtemp, unicode):
                                        featvalues.append("'" + str(valuefieldtemp) + "'")
                                    else:
                                        featvalues.append(str(valuefieldtemp))
                            else:
                                featvalues.append(str(valuefieldtemp))


                sql += ', '.join(featvalues)
                sql += ");"
                # print(sql)
                query = self.dbase.query(sql)
                self.dbase.commit()






        if progress is not None: self.dbase.qgsiface.messageBar().clearWidgets()
        if debug: logging.getLogger('Lamia').debug('end')



    def postImport(self,layerfeat, pkobjet=None, pkdessys=None, pksubdessys=None):
        pass

    def initProgressBar(self, lenprogress):
        """
        Initialise la progress bar d'avancement de la generation du rapport
        :param idsforreportdict:
        :return:
        """
        if self.dbase.qgsiface is not None :
            progressMessageBar = self.dbase.qgsiface.messageBar().createMessage("import ...")
            progress = QProgressBar()

            progress.setMaximum(lenprogress)
            progress.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
            progressMessageBar.layout().addWidget(progress)
            if int(str(self.dbase.qgisversion_int)[0:3]) < 220:
                self.dbase.qgsiface.messageBar().pushWidget(progressMessageBar, self.dbase.qgsiface.messageBar().INFO)
            else:
                self.dbase.qgsiface.messageBar().pushWidget(progressMessageBar, qgis.core.Qgis.Info)
        else:
            progress = None

        return progress

    def setLoadingProgressBar(self, progressbar, val):
        if progressbar is not None:
            progressbar.setValue(val)
        else:
            if self.dbase.qgsiface is None:
                if val%100 == 0:
                    logging.getLogger('Lamia').info('Import de l item %d', val )
        QApplication.processEvents()







class UserUI(QWidget):
    def __init__(self, parent=None):
        super(UserUI, self).__init__(parent=parent)
        # self.setupUi(self)
        uipath = os.path.join(os.path.dirname(__file__), 'Lamia_import_tool.ui')
        uic.loadUi(uipath, self)

