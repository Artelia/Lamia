from qgis.PyQt import uic, QtCore, QtGui
import os, sys
import qgis.core
import logging

try:
    from qgis.PyQt.QtGui import (QWidget,QDialog,QMainWindow,QApplication,QTreeWidgetItem,
                                 QMenu,QToolButton,QSpinBox,QDoubleSpinBox,QHeaderView,QLineEdit,
                                 QTextBrowser,QTreeWidgetItemIterator, QComboBox, QLabel, UserRole, QInputDialog)
except ImportError:
    from qgis.PyQt.QtWidgets import (QWidget,QDialog,QMainWindow,QApplication,QTreeWidgetItem,
                                     QMenu,QToolButton,QSpinBox,QDoubleSpinBox,QHeaderView,QLineEdit,
                                     QTextBrowser,QTreeWidgetItemIterator, QComboBox, QLabel, QInputDialog)

import pprint
import json

class AMCWindow(QDialog):

    def __init__(self, parent=None, dbase=None):
        super(AMCWindow, self).__init__(parent=parent)
        uipath = os.path.join(os.path.dirname(__file__), 'amcwindow1.ui')
        uic.loadUi(uipath, self)
        self.dbase = dbase
        self.dict = {}
        self.count = 0

        # treeWidget
        self.treeWidget.setColumnCount(5)
        self.treeWidget.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.treeWidget.customContextMenuRequested.connect(self.openMenu)

        self.maintreewdgitem = QTreeWidgetItem(self.treeWidget.invisibleRootItem(), ['note'])

        headerlist = ["Criteria", "Select", "Bareme", "Type", "Value", "Vis."]
        self.treeWidget.setHeaderItem(QTreeWidgetItem(headerlist))

        self.treeWidget.header().setStretchLastSection(False)
        self.treeWidget.header().resizeSection(1, 125)
        self.treeWidget.header().resizeSection(2, 75)
        self.treeWidget.header().resizeSection(3, 125)
        self.treeWidget.header().resizeSection(4, 100)
        self.treeWidget.header().resizeSection(5, 75)
        self.treeWidget.header().setResizeMode(0, QHeaderView.Stretch)

        self.treeWidget.itemDoubleClicked.connect(self.itemdoubleclicked)
        self.treeWidget.itemChanged.connect(self.treeitemChanged)

        # Right click on criteria
        self.menu = QMenu()
        self.menu.addAction(self.tr("Add criteria"))
        self.menu.addAction(self.tr("Remove criteria"))
        self.menu.triggered.connect(self.menuAction)

        # Click on Test SQL
        self.toolButton_testsql.clicked.connect(self.testSQL)

        # Click on save
        self.buttonSave.clicked.connect(self.saveClicked)

        self.menuitem = None
        self.itemnameediting = None

        if self.dbase.qgsiface is None:
            self.menuitem = self.maintreewdgitem

            # SELECT = pk_noeud
            # SELECT = pk_descriptionsystem
            self.lineEdit_sqlfinal.setText("FROM #lamia.noeud INNER JOIN #lamia.descriptionsystem ON descriptionsystem.pk_descriptionsystem = noeud.lpk_descriptionsystem")

            """actions = self.menu.actions()
            wdgitem = self.menuAction(actions[0])
            brows = self.treeWidget.itemWidget(wdgitem, 1)
            brows.setText("pk_noeud")
            actions = self.menu.actions()
            wdgitem = self.menuAction(actions[0])
            brows = self.treeWidget.itemWidget(wdgitem, 1)
            brows.setText("pk_descriptionsystem")"""

    def treeitemChanged(self,itemchanged, column):
        self.treeWidget.closePersistentEditor(self.itemnameediting, 0)
        self.itemnameediting = None

    def itemdoubleclicked(self,itemclicked):
        print(itemclicked.text(0))
        if itemclicked == self.maintreewdgitem:
            return
        self.itemnameediting = itemclicked
        self.treeWidget.openPersistentEditor(itemclicked, 0)

    def openMenu(self, position):
        self.menuitem = self.treeWidget.currentItem()
        self.menu.exec_(self.treeWidget.viewport().mapToGlobal(position))

    def menuAction(self, actionname):
        if actionname.text() == self.tr("Add criteria"):
            qtreewidgetitm = QTreeWidgetItem(self.menuitem, ["New criteria"])

            """# Disable parent's SELECT lineEdit and BAREME pushButton
            if qtreewidgetitm.parent():
                try:
                    qtreewidgetitm.parent().itemWidget(node, 1).setEnable(False)
                    qtreewidgetitm.parent().itemWidget(node, 2).setEnable(False)
                except:
                    print("{type}: raised at {fct}".format(type=sys.exc_info()[0].upper(), fct="menuAction"))"""

            # Select
            lineEditSelect = QLineEdit()
            lineEditSelect.setMaximumHeight(25)
            self.treeWidget.setItemWidget(qtreewidgetitm, 1, lineEditSelect)

            # Bareme
            buttonBareme = QToolButton()
            self.treeWidget.setItemWidget(qtreewidgetitm, 2, buttonBareme)
            buttonBareme.setProperty("widgetitem", qtreewidgetitm)
            buttonBareme.clicked.connect(self.baremeButtonPressed)

            # Type
            qComboBox = QComboBox()
            qComboBox.addItems(["Ponderation", "Classe"])
            self.treeWidget.setItemWidget(qtreewidgetitm, 3, qComboBox)
            qComboBox.currentIndexChanged.connect(lambda: self.onComboBoxTypeChanged(qComboBox, qtreewidgetitm))

            # Value
            spinbox = QDoubleSpinBox()
            self.treeWidget.setItemWidget(qtreewidgetitm, 4, spinbox)
            self.menuitem.setExpanded(True)

            # Visualisation
            buttonVisualisation = QToolButton()
            self.treeWidget.setItemWidget(qtreewidgetitm, 5, buttonVisualisation)
            buttonVisualisation.setProperty("widgetitem", qtreewidgetitm)
            buttonVisualisation.clicked.connect(self.baremeVisualisationPressed)

            return qtreewidgetitm

        elif actionname.text() == self.tr("Remove criteria"):
            self.menuitem.parent().removeChild(self.menuitem)

    def onComboBoxTypeChanged(self, comboBoxType, qtreewidgetitm):
        """
        Change treeWidget fourth column given comboBoxType value
        :param comboBoxType: comboBox, comboBox to test
        :param qtreewidgetitm: qTreeWidgetItem, row where to insert new element
        """
        print("> Enter loadComboBoxClass")

        if comboBoxType.currentText() == "Ponderation":
            # Value
            spinbox = QDoubleSpinBox()
            self.treeWidget.setItemWidget(qtreewidgetitm, 4, spinbox)
            self.menuitem.setExpanded(True)
        else:
            # Class value
            comboBoxClass = QComboBox()
            comboBoxClass.addItems(["Max", "Min", "Avg"])
            self.treeWidget.setItemWidget(qtreewidgetitm, 4, comboBoxClass)

        print("> Exit loadComboBoxClass")

    def baremeButtonPressed(self):
        print("> Barement button pressed")

    def baremeVisualisationPressed(self):
        print("> Visualisation button pressed")

    def saveClicked(self):
        print("> Save clicked")

        # Ask file name to user
        fileName = self.getName()

        # Cancel saving
        if fileName is None or fileName == "":
            return

        # Reset self.dict
        self.dict.clear()
        self.count = 0

        # Fill self.dict
        self.visitTree(self.maintreewdgitem, self.dict)
        pprint.pprint(self.dict)

        # Create file path
        directory = self.dbase.dbaseressourcesdirectory + "/config/amcTools/" + fileName
        # Creates file and writes queryDict as json
        with open(directory, "w") as file:
            json.dump(self.dict, file)

    def visitTree(self, node, dct, parentKey=""):
        """
        Iterate over the tree and build dct
        :param node: QTreeWidgetItem, current node
        :param dct: dict, contain elements from current node
        :param parentKey: str, current looped key. Init at "" for root
        """

        print("Enter visitTree, node:", node.text(0))

        # Get number of child
        childNr = node.childCount()

        # If node is leaf
        if childNr == 0:
            print(">", node.text(0), "has no child")

            # Retrieve data from current node
            lineEditSelect = self.treeWidget.itemWidget(node, 1)
            select = lineEditSelect.text()

            qComboBox = self.treeWidget.itemWidget(node, 3)
            valueType = qComboBox.currentText()

            # Check fourth column type
            fourthColumn = self.treeWidget.itemWidget(node, 4)
            if isinstance(fourthColumn, QDoubleSpinBox):
                spinbox = self.treeWidget.itemWidget(node, 4)
                value = spinbox.value()
            else:
                comboBoxClass = self.treeWidget.itemWidget(node, 4)
                value = comboBoxClass.currentText()

            # Set default dict values
            dct.setdefault("Name", node.text(0))
            dct.setdefault("Select", select)
            dct.setdefault("Bareme", "TBD")
            dct.setdefault("Type", valueType)
            dct.setdefault("Value", value)

        # If node has children
        else:
            print(">", node.text(0), "has children")
            # Loop through children and add them to dct
            for childItem in range(childNr):

                # Define currentKey
                currentKey = str(parentKey) + str(childItem + 1)

                # Define current node
                child = node.child(childItem)
                dct.setdefault(currentKey, {})

                # Loop through children recursively
                self.visitTree(child, dct[currentKey], currentKey)

        print("Exit visitTree, node:", node.text(0))

    # ---------- FILE MANAGEMENT SYSTEM ----------

    def getName(self):
        """
        Ask user for a file name
        :return: str, name if correct, None otherwise
        """
        text, ok = QInputDialog.getText(self, "Create a new IKDIJFIDJFIDJFLFJLDKJFLD", "File name")
        if ok:
            return str(text + ".json")
        return None











    def testSQL(self):
        print('testSQL')

        sql={}
        sql['final']=''
        sql['critere']=[]

        sql['final'] = self.lineEdit_sqlfinal.text()

        iterator = QTreeWidgetItemIterator(self.treeWidget, QTreeWidgetItemIterator.All)
        while iterator.value():
                item = iterator.value()
                itemwdg = self.treeWidget.itemWidget(item,1)
                if isinstance(itemwdg, QTextBrowser):
                    sql['critere'].append( itemwdg.toPlainText() )
                iterator+=1

        #print(sql)
        self.createVLayer(sql)

    def createVLayer(self,sqlsict):
        debug = True

        self.textBrowser_res.clear()

        if debug: logging.getLogger("Lamia").debug('sqlsict %s', str(sqlsict))

        layers={}
        sqlfinal='SELECT '

        for sql in sqlsict['critere']:
            layersql, sentencesql = self.analyseRawSQL(sql)
            for vlayername, vlayersql in layersql:
                if not vlayername in layers.keys():
                    layers[vlayername] = vlayersql
            sqlfinal += sentencesql + ', '
        sqlfinal = sqlfinal[:-2]

        layersql, sentencesql = self.analyseRawSQL(sqlsict['final'])
        for vlayername, vlayersql in layersql:
            if not vlayername in layers.keys():
                layers[vlayername] = vlayersql

        sqlfinal += sentencesql
        sqlfinal = self.dbase.updateQueryTableNow(sqlfinal)
        #sqlfinal += sqlsict['final']

        if debug: logging.getLogger("Lamia").debug('********************* ')
        if debug: logging.getLogger("Lamia").debug('layers %s', str(layers))
        if debug: logging.getLogger("Lamia").debug('sqlfinal %s', str(sqlfinal))

        #scriptvl = '?' + str(QtCore.QUrl.toPercentEncoding('&'.join([layers[key] for key in layers.keys()])))
        scriptvl = '?' + '&'.join([layers[key] for key in layers.keys()])
        if sys.version_info.major == 2:
            scriptvl += "&query=" + str(QtCore.QUrl.toPercentEncoding(sqlfinal))
        elif sys.version_info.major == 3:
            scriptvl += '&query=' + QtCore.QUrl.toPercentEncoding(sqlfinal).data().decode('utf-8')
        #scriptvl += "&query=" + QtCore.QUrl.toPercentEncoding(sqlfinal)

        if debug: logging.getLogger("Lamia").debug('scriptvl %s', str(scriptvl))

        vlayer = qgis.core.QgsVectorLayer(scriptvl, "vlayer", "virtual")
        self.textBrowser_res.append(str(vlayer.isValid()))
        #print('vlayer', vlayer.isValid())

        for fet in vlayer.getFeatures():
            #print(fet.attributes())
            self.textBrowser_res.append(str(fet.attributes()))










    def analyseRawSQL(self,sql):
        layersql, sentencesql = [], ''


        if '#' in sql:
            sqlssplitspace = sql.split(' ')
            for sqlsplitspace in sqlssplitspace:
                if '#' in sqlsplitspace:

                    tabletype, tablename = sqlsplitspace.split('.')
                    if tabletype == '#lamia':
                        if '_now' in tablename:
                            rawtablename = '_'.join(tablename.split('_')[:-1])
                            tablenamevlayer = '_'.join(tablename.split('_')[:-1]) + '_qgis'
                        elif '_qgis' in tablename:
                            rawtablename = '_'.join(tablename.split('_')[:-1])
                            tablenamevlayer = '_'.join(tablename.split('_')[:-1]) + '_qgis'
                        else:
                            rawtablename = tablename
                            tablenamevlayer = tablename


                        vlayerlayer = "layer=spatialite:"
                        print(self.dbase.spatialitefile)
                        print(os.path.normpath(self.dbase.spatialitefile))

                        print('rawtablename',rawtablename,tablenamevlayer)


                        if sys.version_info.major == 2:
                            if self.dbase.isTableSpatial(rawtablename):
                                vlayerlayer += str(QtCore.QUrl.toPercentEncoding("dbname='" + self.dbase.spatialitefile
                                                                                 + "' key ='pk_" + rawtablename.lower() +"' "
                                                                                 + 'table="' + tablenamevlayer.lower() + '"'
                                                                                 + ' (geom) sql='))
                            else:
                                vlayerlayer += str(QtCore.QUrl.toPercentEncoding("dbname='" + self.dbase.spatialitefile
                                                                                 + "' key ='pk_" + rawtablename.lower() +"' "
                                                                                 + 'table="' + tablenamevlayer.lower() + '"'
                                                                                 + ' () sql='))
                        elif sys.version_info.major == 3:
                            if self.dbase.isTableSpatial(rawtablename):
                                vlayerlayer += QtCore.QUrl.toPercentEncoding("dbname='" + self.dbase.spatialitefile
                                                                                 + "' key ='pk_" + rawtablename.lower() +"' "
                                                                                 + 'table="' + tablenamevlayer.lower() + '"'
                                                                                 + ' (geom) sql=').data().decode('utf-8')
                            else:
                                vlayerlayer += QtCore.QUrl.toPercentEncoding("dbname='" + self.dbase.spatialitefile
                                                                                 + "' key ='pk_" + rawtablename.lower() +"' "
                                                                                 + 'table="' + tablenamevlayer.lower() + '"'
                                                                                 + ' () sql=').data().decode('utf-8')



                        if False:
                            vlayerlayer += ("dbname='" + self.dbase.spatialitefile + "' "
                                             + "key='pk_" + rawtablename.lower() +"' "
                                             + 'table="' + tablenamevlayer.lower() + '"'
                                             + ' (geom) sql=')
                        vlayerlayer += ":" + str(tablenamevlayer.lower()) + ":UTF8"

                        layersql.append([tablenamevlayer, vlayerlayer])
                        sentencesql += ' ' + tablename


                else:
                    sentencesql += ' ' + sqlsplitspace
                    continue
        else:
            sentencesql = sql

        return layersql, sentencesql


